require 'bunny'
require 'json'
require 'securerandom' # Added to fix the SecureRandom error

# Connect to RabbitMQ
connection = Bunny.new
connection.start

# Create a channel and declare the 'orders' queue
channel = connection.create_channel
queue = channel.queue('orders', durable: true)

# Generate and send structured JSON messages
puts 'Enter order details. Type "exit" to quit.'

loop do
  # Example JSON message structure
  message = {
    id: SecureRandom.uuid,
    createdAt: Time.now.to_i,
    items: [
      {
        id: SecureRandom.uuid,
        name: "USB-C Dongle",
        price: 14.99,
        quantity: 1
      },
      {
        id: SecureRandom.uuid,
        name: "8k Camera",
        price: 849.79,
        quantity: 1
      }
    ],
    customer: {
      id: SecureRandom.uuid,
      name: "Jane Doe",
      mail: "jane@doe.com"
    }
  }

  # Convert the message to JSON
  json_message = JSON.generate(message)

  # Publish the message
  queue.publish(json_message)
  puts " [x] Sent: #{json_message}"

  print '> Type "exit" to stop or press Enter to send another message: '
  input = gets.chomp
  break if input.downcase == 'exit'
end

# Close the connection
connection.close
